Feature:
     Automation Exercise Application Demo
     
Scenario Outline:

    		Add a product to the cart 
     
 Given User should navigate to the application Login
 Given User cicks on the Login link
 Given User enter login as "<username>" and "<password>"
 Given User click the login button
 Given User search a "<product>"
 When  User add the product to the cart 
 When  The cart badge should be updated
 When  User click the check out button
 Then  Display The list of added products in the cart
 
 Examples:

|       username        |  password     |    product
| Demosample1@gmail.com | DEMOSAMPLE    | PREMIUM POLO T-Shirts
| Demosample1@gmail.com | DEMOSAMPLE    | Little Girls Mr. Panda Shirt
| Demosample2@gmail.com | demosample123 | Sleeves Printed Top - White
| Demosample2@gmail.com | demosample123 | Sleeves Top and Short - Blue & Pink
| Demosample1@gmail.com |  DEMOSAMPLE   | Rose Pink Embroidered Maxi Dress

 
