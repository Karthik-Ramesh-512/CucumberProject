package Step;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Step_Definition {
	
WebDriver driver;
ChromeOptions options = new ChromeOptions();
	  
	
	@Given("User should navigate to the application Login")	
    public void UserShouldNavigateToTheApplicationLogin()
    {
		WebDriverManager.chromedriver().setup();
		options.addArguments("--disable-notifications");
		options.addArguments("--disable-popup-blocking");
		driver = new ChromeDriver(options);
		driver.get("https://www.automationexercise.com/login");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));  
	            
    }
	
	@Given("User cicks on the Login link")
	public void userCicksOnTheLoginLink() {

	}
	
	@Given("User enter login as {string} and {string}")
	public void userEnterLoginAsAnd(String string, String string2) {
		driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys(string);
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(string2);
	    
	}
	
	@Given("User click the login button")
	public void userClickTheLoginButton() throws Exception {		
		 WebElement login = driver.findElement(By.xpath("//button[normalize-space()='Login']"));
         login.click();	  
         Thread.sleep(3000);
         
	}
	
	@Given("User search a {string}")
	public void userSearchA(String string) throws Exception {
		options.addArguments("--disable-notifications");
		options.addArguments("--disable-popup-blocking");
		driver.findElement(By.xpath("//a[@href='/products']")).click();
		//driver.findElement(By.xpath("//input[@id='search_product']")).click();
		driver.findElement(By.xpath("//input[@id='search_product']")).sendKeys(string);
		driver.findElement(By.xpath("//button[@id='submit_search']")).click();
		
	    
	}
	
	@When("User add the product to the cart")
	public void userAddTheProductToTheCart() {
		driver.findElement(By.xpath("//div[@class='productinfo text-center']//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart']")).click();
	    
	}
	
	@When("The cart badge should be updated")
	public void theCartBadgeShouldBeUpdated() {
		driver.findElement(By.xpath("//button[normalize-space()='Continue Shopping']")).click();
	    
	}
	
	@When("User click the check out button")
	public void userClickTheCheckOutButton() {
		driver.findElement(By.xpath("//header[@id='header']//li[1]")).click();
	   
	}
	
	@Then("Display The list of added products in the cart")
	public void displayTheListOfAddedProductsInTheCart() {
	    
	}
	

}
