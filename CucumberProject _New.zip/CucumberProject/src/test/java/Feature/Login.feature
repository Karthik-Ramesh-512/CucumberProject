Feature:
     Bookart Application Demo
     
Scenario:

     Login should be success
     
 Given User should navigate to the application Login
 And   User cicks on the Login link
 And   User enter username as Admin
 And   User enter password as admin123
 When  User click the login button
 Then Login should be success
 
Scenario:
     
     Login should be failed
     
 Given User should navigate to the application Login
 And   User cicks on the Login link
 And   User enter username as Admin1
 And   User enter password as password12
 When  User click the login button
 But Login should be failed

 

 
