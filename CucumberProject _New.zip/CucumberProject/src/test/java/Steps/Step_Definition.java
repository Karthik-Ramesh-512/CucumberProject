package Steps;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Step_Definition {
	
	WebDriver driver;
	  
	
	@Given("User should navigate to the application Login")	
    public void UserShouldNavigateToTheApplicationLogin()
    {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));   
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }
	
	@Given("User cicks on the Login link")
	public void userCicksOnTheLoginLink() {	    
	}
	
	@Given("User enter username as Admin")
	public void userEnterUsernameAsAdmin() {
		WebElement user = driver.findElement(By.name("username"));
        user.sendKeys("Admin"); 
	}
	
	@Given("User enter password as admin123")
	public void userEnterPasswordAsadmin123() {		
		WebElement pass = driver.findElement(By.name("password"));
        pass.sendKeys("admin123"); 	    
	}
	
	@When("User click the login button")
	public void userClickTheLoginButton()  {		
		 WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
         login.click();	  
         
	}
	
	@Then("Login should be success")
	public void loginShouldBeSuccess() {		
		System.out.println("Login Successful!!");	
		driver.quit();
	}	
	
}
