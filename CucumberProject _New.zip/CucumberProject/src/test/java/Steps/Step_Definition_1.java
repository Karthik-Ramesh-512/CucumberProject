package Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Step_Definition_1 {
	
	WebDriver driver;
	
	@Given("User enter username as Admin1")
	public void userEnterUsernameAsAdmin1() {
		WebElement user = driver.findElement(By.name("username"));
        user.sendKeys("Admin1"); 
	}
	@Given("User enter password as password12")
	public void userEnterPasswordAsPassword12() {
		WebElement pass = driver.findElement(By.name("password"));
        pass.sendKeys("password12"); 	
	}
	@When("User click the login button")
	public void userClickTheLoginButton() {
		 WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
         login.click();	 
	}
	@When("Login should be failed")
	public void loginShouldBeFailed() {
	   String errormsg = driver.findElement(By.xpath("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']")).getText();
	   Assert.assertEquals(errormsg, "Invalid credentials");
	   driver.quit();
	}

}
