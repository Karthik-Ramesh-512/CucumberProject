package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@CucumberOptions(
		features = {"src/test/java/Feature/Login.feature"},
		dryRun = !true,
		glue = "Steps",
		snippets = SnippetType.CAMELCASE
		
		
		)
public class Runner extends AbstractTestNGCucumberTests{

}
