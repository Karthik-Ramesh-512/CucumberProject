package Steps;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Step_Definition {

WebDriver driver;
	  
	
	@Given("User should navigate to the application Login")	
    public void UserShouldNavigateToTheApplicationLogin()
    {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));   
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }
	
	@Given("User cicks on the Login link")
	public void userCicksOnTheLoginLink() {
	    
	}
	
	@Given("User enter username as {string}")
	public void userEnterUsernameAs(String string) {
		WebElement user = driver.findElement(By.name("username"));
        user.sendKeys(string); 
	}
	
	@Given("User enter password as {string}")
	public void userEnterPasswordAs(String string) {		
		WebElement pass = driver.findElement(By.name("password"));
        pass.sendKeys(string); 	    
	}
	
		
	@When("User click the login button")
	public void userClickTheLoginButton()  {		
		 WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
         login.click();	  
         
	}
	
	@Then("Login should be success")
	public void loginShouldBeSuccess() {		
		System.out.println("Login Successful!!");	
		driver.quit();
	}	
	
	@Then("Login should be failed")
	public void loginShouldBeFailed() {
	   String errormsg = driver.findElement(By.xpath("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']")).getText();
	   //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	   Assert.assertEquals(errormsg, "Invalid credentials");
	   System.out.println("Login Failed!!");
	   driver.quit();
	}
	
}


