Feature:
     Bookart Application Demo
     
Background:
 Given User should navigate to the application Login
 And   User cicks on the Login link
 When  User click the login button
 
     
Scenario:

     Login should be success     

 And   User enter username as "Admin"
 And   User enter password as "admin123" 
 Then Login should be success
 
Scenario:
     
     Login should be failed
     
 And   User enter username as "Admin123"
 And   User enter password as "password12"  
 Then  Login should be failed